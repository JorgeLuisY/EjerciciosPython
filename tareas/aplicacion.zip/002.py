n= float(raw_input("n: "))
c= 2.0
S=0
while c<=n:
    S=S+(1/c)
    c+=2
    print S
