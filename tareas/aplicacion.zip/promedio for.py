a=[15,16,16,15,17,20]
suma=0
for i in a:
    suma+=i
    i+=1
print float(suma)/float(len(a))
