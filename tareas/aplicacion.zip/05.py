a= int(raw_input("a: "))
b= int(raw_input("b: "))
while a<=b:
    print a
    a+=1
