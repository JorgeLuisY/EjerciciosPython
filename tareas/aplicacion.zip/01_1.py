Numero =int(raw_input("ingrese un n�mero: "))
if Numero ==0:
    print ("cero: ")
if Numero %2 ==0:
    print ("par: ")
else:
    print ("impar: ")
