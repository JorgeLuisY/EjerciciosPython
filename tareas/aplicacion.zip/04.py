# ejerccico 5..... 2,4,6,8...n
num=2
n=int(raw_input("ingresa numero: "))
while num <=n:
    print num
    num +=2
    
