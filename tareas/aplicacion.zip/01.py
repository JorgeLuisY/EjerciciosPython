for i in range(5,20):
    print i
