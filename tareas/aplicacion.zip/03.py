numero=1
n= int(raw_input("ingrese un numero: "))
while numero <=n:
    print numero
    numero +=1
