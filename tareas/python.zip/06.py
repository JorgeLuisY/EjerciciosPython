S=0
a=1
while a<=100:
    S=S+a
    a+=1
    print S
