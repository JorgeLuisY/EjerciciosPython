a=[4,5,7,12,1,5]
b=[]
b.append (a[0])
b.append (a[1])
b.append (a[2])
b.append (a[3])
b.append (a[4])
b.append (a[5])
print b
