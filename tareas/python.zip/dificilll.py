A=[9,15,20,18,17,14,110]
B=[]
i=len(A)-1
while i>=0:
    B.append(A[i])
    i-=1
print A
print B
