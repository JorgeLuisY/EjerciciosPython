numero =18
while numero >=2:
    print numero
    numero -=2
