def factorial(N):
    fac=1
    a=1
    while a<=N:
        fac*=a
        a+=1
    print fac
factorial(5)
factorial(3)
factorial(7)
