#funciones que reciben y devuelven parametros
def factorial(N):
    fac=1
    a=1
    while a<=N:
        fac*=a
        a+=1
    return fac
resultado=factorial(5)*10
print "resultado= ",resultado
