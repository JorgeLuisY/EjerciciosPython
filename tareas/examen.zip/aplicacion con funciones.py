#aplicacion utilizan funciones
persona=[]
def menu():
    print "menu"
    print "1.agregar"
    print "2.reportar"
    print "3.eliminar"
    print "4.salir"
def agregar():
    dni=raw_input("DNI: ")
    nombre=raw_input("NOMBRE: ")
    apellido=raw_input("APELLIDO: ")
    edad=raw_input("EDAD: ")
    persona.append([dni,nombre,apellido,edad])
def reportar():
    fila=0
    while fila<len(persona):
        print fila+1,"\t",persona[fila][0],"\t",persona[fila][1],"\t",persona[fila][2],"\t",persona[fila][3]
        fila+=1
def eliminar():
    reportar()
    print "Seleccione la persona que desea eliminar"
    num=int(raw_input("posicion: "))
    persona.pop(num-1)
    print "persona eliminada...."
opcion = 1
while opcion!=4:
    menu()
    opcion=int(raw_input("selecione [1-4]: "))
    if opcion==1:
        agregar()
    if opcion==2:
        reportar()
    if opcion==3:
        eliminar()
