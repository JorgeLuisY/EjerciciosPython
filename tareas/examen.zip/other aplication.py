persona=[]
opcion=1
while opcion!=4:
    print "*** Men� ***"
    print "1. Agregar"
    print "2. Reporte"
    print "3. Eliminar"
    print "4. Salir"
    opcion= int(raw_input("Ingrese opcion: "))
    if opcion ==1:
        dni=raw_input("DNI: ")
        nombre=raw_input("Nombre: ")
        apellido=raw_input("Apellido: ")
        edad=raw_input("Edad: ")
        persona.append([dni,nombre,apellido,edad])
    if opcion ==2:
        for i in persona:
            print i
    if opcion==3:
        for i in persona:
            print i
            posicion_eliminar=int(raw_input("Ingrese posicion: "))
            persona.pop(posicion_eliminar)
    else:
        print salir
            
            
        
