#-*-

def saludo():
    print "Bienvenidos al sistema"
    print "Universidad Peruana Uni�n"
    print "Facultad de Ingenieria y Arquitectura"
    print "EAP de Ingenieria de Sistemas"
saludo()
